# create-flask-app
Shell script for creating a ready-to-go template for you flask project.

